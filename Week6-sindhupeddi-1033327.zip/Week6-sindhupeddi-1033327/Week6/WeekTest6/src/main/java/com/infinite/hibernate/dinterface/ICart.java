package com.infinite.hibernate.dinterface;
import com.infinite.hibernate.pojo.Cart;



public interface ICart {

	public void createRecord(String product_name,int price,int quantity,int subtotal,Cart ca);

 

	public void updateRecord();

 

	public void deleteRecords();

 

 

}

