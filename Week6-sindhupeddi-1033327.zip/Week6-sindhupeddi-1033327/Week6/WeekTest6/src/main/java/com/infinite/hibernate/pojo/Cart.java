package com.infinite.hibernate.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class Cart {
	@Id
	@Column(name = "product_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "product_name")
	private String product;
	@Column(name = "price")
	private int price;
	@Column(name = "quantity")
	private int quantity;
	@Column(name = "subtotal")
	private int subtotal;

	public Cart() {

	}

	public Cart(String product, int price, int quantity, int subtotal) {
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		this.subtotal = subtotal;
	}

	public int getId() {

		return id;

	}

	public void setId(int id) {
		this.id = id;

	}

	public String getProduct() {

		return product;

	}

	public void setProduct(String product) {

		this.product = product;

	}

	public int getPrice() {

		return price;

	}

	public void setPrice(int price) {

		this.price = price;

	}

	public int getQuantity() {

		return quantity;

	}

	public void setQuantity(int quantity) {

		this.quantity = quantity;

	}

	public int getSubtotal() {

		return subtotal;

	}

	public void setSubtotal(int subtotal) {

		this.subtotal = subtotal;

	}

}
