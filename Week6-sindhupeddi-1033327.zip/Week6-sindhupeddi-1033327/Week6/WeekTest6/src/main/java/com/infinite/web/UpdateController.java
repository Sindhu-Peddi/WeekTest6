package com.infinite.web;

public class UpdateController {

}
