package com.infinite.web;


import com.infinite.hibernate.dimpl.CartImplementation;

import com.infinite.hibernate.pojo.Cart;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

 

public class InsertController {

	private static final Logger logger= Logger.getLogger(InsertController.class);

	private ApplicationContext con;

	@RequestMapping(value="/insert",method=RequestMethod.POST)

	public String insert(@ModelAttribute("bean") Cart e,Model m){

		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");

		CartImplementation obj=con.getBean("dao",CartImplementation.class);

		obj.createRecord("Box", 20, 10, 200, e);

		String Product=e.getProduct();

		int Price=e.getPrice();

		int Quantity=e.getQuantity();

		int subtotal=e.getSubtotal();

		//Session sessionobj = sessionFactory;

		m.addAttribute("msg",Product);

		logger.info("Create Controller");

		return "update";	

	}

}

